<div id="main_content1">

<h3>

<p>You can contact us via the Multimedia Department of ROCANA INSTITUTE OF TECHNOLOGY</p>
<p>Address: 37/38 ABIRIBA STREET, EMENE INDUSTRIAL LAYOUT, BY STRABAG BUS STOP, EMENE, ENUGU, NIGERIA.</p>
<p>Site Admin Number: 080-6645-9789</p>
<p>Site Admin E-mail: vifeanyi33@gmail.com</p>
<p>You can use the below form to contact us more faster</p>


<p><iframe frameborder="0" src="mail.php" width="70%" height="70%"></iframe></p></br>




</h3>

</center>
</div>
