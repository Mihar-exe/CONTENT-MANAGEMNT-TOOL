<div id="main_content1">

<h3>
<p>This website is developed and dedicated to </p>
<p>all the students in ROCANA INSTITUTE</p>
 <p>OF TECHNOLOGY. In this website, you can </p>
 <p>find all the basic tutorials needed in </p>
 <p>Autodesk 3dsmax. This website was developed </p>
 <p>by an NID2 student by name <b><u>Ejiogu Victor Ifeanyi</u></b></p>
<p> being a bona-fide student of the Institute as a </p>
<p> project work. ROCANA INSTITUTE OF TECHNOLOGY is </p>
 <p>an innovative Institute that provide their students </p>
 <p>with all they need to be creative and be self </p>
 <p>employed after their program in the Institute.</p>
 </h3>

</center>
</div>
