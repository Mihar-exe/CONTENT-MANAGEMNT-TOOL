<div id="header">
<div id="logo"><img src="images/logo.jpg"></div>
<div id="banner"><img src="images/banner.jpg">
</div>