<html>
	<head>
		<title>Welcome to Ritcreativehub</title>
		
<link rel="stylesheet" href="style.css" media="all">
	</head>
	
<body>
<div><?php include("includes/header.php"); ?></div>
<div><?php include("includes/navbar.php"); ?></div>
<div><?php include("includes/main_content3.php"); ?></div>




</div>




<div id="footer">
<p align="center" ><font color="gray">&copy 2014. Victor (0806-645-9789)</font></p>






</body>
</html>